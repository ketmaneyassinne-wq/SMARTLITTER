import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'SmartLitter — A cleaner kind of cat life',
  description: 'Thoughtful smart litter solutions for cats and the people who love them.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
