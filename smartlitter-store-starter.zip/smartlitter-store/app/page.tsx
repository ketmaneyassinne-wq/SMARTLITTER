'use client';

import { useMemo, useState } from 'react';
import { ArrowDownRight, ArrowRight, Check, ChevronDown, Heart, Menu, Minus, Plus, ShoppingBag, Sparkles, X } from 'lucide-react';

type Product = { id: number; name: string; subtitle: string; price: number; oldPrice?: number; tag: string; color: string; shape: string; };
const products: Product[] = [
  { id: 1, name: 'SmartLitter One', subtitle: 'Self-cleaning litter box', price: 249, oldPrice: 329, tag: 'THE EVERYDAY UPGRADE', color: 'sand', shape: 'one' },
  { id: 2, name: 'SmartLitter Plus', subtitle: 'Roomier. Smarter. Easier.', price: 329, oldPrice: 399, tag: 'MORE ROOM TO ROAM', color: 'sage', shape: 'plus' },
  { id: 3, name: 'OdourLock Pods', subtitle: 'Freshness, made simple', price: 19, tag: 'THE LITTLE ESSENTIAL', color: 'peach', shape: 'pods' },
];

function ProductArt({ shape, color }: { shape: string; color: string }) {
  return <div className={`product-art ${color} ${shape}`} aria-label="Illustration of a smart cat litter product" role="img">
    {shape !== 'pods' ? <>
      <div className="machine-top"><span className="sensor" /></div>
      <div className="machine-opening"><div className="inner-shadow" /><div className="litter-bed" /></div>
      <div className="machine-base"><span className="brand-dot">s.</span><span className="status-light" /></div>
      <div className="machine-foot foot-left" /><div className="machine-foot foot-right" />
    </> : <><div className="pod pod-a"/><div className="pod pod-b"/><div className="pod pod-c"/><div className="pod-label">ODŌR<br/>LOCK</div></>}
    <span className="art-sparkle sparkle-a">✳</span><span className="art-sparkle sparkle-b">✦</span>
  </div>;
}

export default function Home() {
  const [cart, setCart] = useState<Record<number, number>>({});
  const [cartOpen, setCartOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [currency, setCurrency] = useState<'USD' | 'GBP'>('USD');
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  const total = useMemo(() => products.reduce((sum, p) => sum + p.price * (cart[p.id] || 0), 0), [cart]);
  const money = (n: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n * (currency === 'GBP' ? 0.79 : 1));
  const add = (id: number) => setCart(c => ({ ...c, [id]: (c[id] || 0) + 1 }));
  const change = (id: number, by: number) => setCart(c => { const next = { ...c, [id]: Math.max(0, (c[id] || 0) + by) }; if (!next[id]) delete next[id]; return next; });

  return <main>
    <div className="announcement"><Sparkles size={13} /> A little less scooping. A lot more living. <span className="announcement-link">MEET YOUR NEW FAVOURITE <ArrowRight size={12}/></span></div>
    <header className="site-header">
      <button className="icon-button mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Open menu">{menuOpen ? <X/> : <Menu/>}</button>
      <a className="logo-wrap" href="#top" aria-label="SmartLitter home"><img src="/smartlitter-logo.svg" alt="SmartLitter" /></a>
      <nav className={menuOpen ? 'nav-links nav-open' : 'nav-links'}><a href="#shop" onClick={() => setMenuOpen(false)}>Shop</a><a href="#how-it-works" onClick={() => setMenuOpen(false)}>How it works</a><a href="#why-smartlitter" onClick={() => setMenuOpen(false)}>Why SmartLitter</a><a href="#faq" onClick={() => setMenuOpen(false)}>FAQs</a></nav>
      <div className="header-actions"><label className="currency-select"><span className="sr-only">Currency</span><select value={currency} onChange={e => setCurrency(e.target.value as 'USD' | 'GBP')}><option value="USD">US $</option><option value="GBP">UK £</option></select><ChevronDown size={12}/></label><button className="bag-button" onClick={() => setCartOpen(true)}><ShoppingBag size={17}/><span>Bag</span><b>{count}</b></button></div>
    </header>

    <section className="hero" id="top">
      <div className="hero-copy"><div className="eyebrow"><span className="eyebrow-dot"/> A BETTER KIND OF CAT CARE</div><h1>Less litter<br/>drama. <em>More</em><br/><span>cat&nbsp; cuddles.</span></h1><p>Smart litter boxes that do the dirty work, so you can get back to the good stuff.</p><div className="hero-buttons"><a className="button button-dark" href="#shop">Shop smart litter <ArrowRight size={16}/></a><a className="text-link" href="#how-it-works">How it works <ArrowDownRight size={15}/></a></div><div className="hero-proof"><div className="avatar-stack"><span>🐱</span><span>🐈</span><span>😺</span></div><div><strong>For cats. For their people.</strong><small>Better routines start here.</small></div></div></div>
      <div className="hero-visual"><div className="hero-sticker"><span>GOODBYE</span><strong>SCOOPING</strong><span>HELLO FREE TIME ✳</span></div><div className="hero-sun"/><div className="hero-product"><ProductArt shape="one" color="sand"/></div><div className="hero-cat">🐈</div><div className="hero-caption"><span>01 / THE EVERYDAY UPGRADE</span><span>Designed for real life ↗</span></div><div className="floating-note"><span className="note-icon"><Sparkles size={18}/></span><span><strong>A fresher-feeling home</strong><small>One smart step at a time.</small></span></div></div>
      <div className="hero-bottom-label">GOOD THINGS COME IN CAT HAIR</div>
    </section>

    <section className="benefit-strip" id="why-smartlitter"><div><span className="benefit-icon">✳</span><span><strong>Less daily scooping</strong><small>Give your routine a break</small></span></div><div><span className="benefit-icon">♡</span><span><strong>Made for cat people</strong><small>Practical, thoughtful design</small></span></div><div><span className="benefit-icon">☼</span><span><strong>Home-friendly looks</strong><small>Pet gear that fits your space</small></span></div><div><span className="benefit-icon">↗</span><span><strong>Help when you need it</strong><small>We're here for the questions</small></span></div></section>

    <section className="shop-section section-pad" id="shop"><div className="section-heading"><div><div className="eyebrow">THE SMARTER SIDE OF LITTER</div><h2>Your cat's new<br/><em>favourite room.</em></h2></div><div className="heading-aside"><p>Small upgrades. Happier routines. A home that feels a little more yours again.</p><a className="text-link" href="#shop">Explore the collection <ArrowRight size={15}/></a></div></div>
      <div className="product-grid">{products.map((p, i) => <article className="product-card" key={p.id}><div className="product-card-art"><span className="product-tag">{p.tag}</span><button className="wishlist" aria-label={`Save ${p.name}`} onClick={e => e.currentTarget.classList.toggle('liked')}><Heart size={17}/></button><ProductArt shape={p.shape} color={p.color}/><span className="product-number">0{i + 1}</span></div><div className="product-info"><div><h3>{p.name}</h3><p>{p.subtitle}</p></div><div className="price-block"><strong>{money(p.price)}</strong>{p.oldPrice && <del>{money(p.oldPrice)}</del>}</div></div><button className="add-button" onClick={() => { add(p.id); setCartOpen(true); }}>Add to bag <Plus size={15}/></button></article>)}</div>
      <p className="prototype-note">Product names, prices and product visuals are starter placeholders. Replace these with verified supplier products, accurate specs and real photos before taking orders.</p>
    </section>

    <section className="manifesto" id="how-it-works"><div className="manifesto-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="manifesto-cat">🐈‍⬛</div><div className="manifesto-stamp">PETS FIRST<br/>ALWAYS ✳</div><span className="manifesto-star star-one">✳</span><span className="manifesto-star star-two">✦</span></div><div className="manifesto-copy"><div className="eyebrow">WE GET IT. YOU LOVE YOUR CAT.</div><h2>It's the cat's<br/>house. <em>We're just<br/>living in it.</em></h2><p>We believe the best pet tech doesn't make life more complicated. It quietly takes one annoying thing off your plate, and gives you more time for the tiny creature running the place.</p><a className="button button-light" href="#shop">Find your smart setup <ArrowRight size={16}/></a></div></section>

    <section className="steps-section section-pad"><div className="eyebrow">NO PhD IN CAT REQUIRED</div><h2>Smart should feel <em>simple.</em></h2><div className="steps-grid"><div className="step"><span className="step-number">01</span><div className="step-illustration">📦</div><h3>Pick your setup</h3><p>Find the right fit for your cat, your home and your routine.</p></div><div className="step"><span className="step-number">02</span><div className="step-illustration">🐾</div><h3>Make it theirs</h3><p>Give your cat time to get comfortable with something new.</p></div><div className="step"><span className="step-number">03</span><div className="step-illustration">☕</div><h3>Get on with life</h3><p>Spend less time on litter chores and more time together.</p></div></div></section>

    <section className="newsletter"><div className="newsletter-doodle">✳</div><div><div className="eyebrow">THE OCCASIONAL CAT EMAIL</div><h2>Good things for<br/><em>good cats.</em></h2><p>Product news, cat-life tips and the odd excellent cat photo. No inbox litter.</p></div><form className="newsletter-form" onSubmit={e => { e.preventDefault(); if (email.includes('@')) setSubscribed(true); }}><label htmlFor="email">YOUR EMAIL ADDRESS</label><div className="email-field"><input id="email" type="email" placeholder="you@somewhere.com" value={email} onChange={e => setEmail(e.target.value)} required/><button aria-label="Subscribe"><ArrowRight size={18}/></button></div><small>{subscribed ? 'You’re on the list. Thanks for being here!' : 'By subscribing, you agree to receive SmartLitter updates.'}</small></form></section>

    <section className="faq-section section-pad" id="faq"><div><div className="eyebrow">GOOD QUESTION</div><h2>Before you<br/><em>ask your cat.</em></h2></div><div className="faq-list"><details><summary>Are these products suitable for every cat?<Plus size={17}/></summary><p>It depends on the specific model, your cat's size, age and comfort. Always check the manufacturer's age, weight and safety guidance before buying.</p></details><details><summary>How does a self-cleaning litter box work?<Plus size={17}/></summary><p>Models differ. Many use a rotating or raking mechanism to separate waste after use. Follow the product instructions and keep the box clean and monitored.</p></details><details><summary>How long does shipping take?<Plus size={17}/></summary><p>Shipping estimates will be shown here once the supplier, fulfilment location and delivery regions are confirmed.</p></details><details><summary>Can I return my order?<Plus size={17}/></summary><p>Our final return policy will be published before launch and will explain eligibility, timeframes and how to contact support.</p></details></div></section>

    <footer className="footer"><div className="footer-top"><div className="footer-brand"><img src="/smartlitter-logo.svg" alt="SmartLitter"/><p>A little less litter.<br/>A lot more living.</p></div><div className="footer-links"><div><strong>THE SHOP</strong><a href="#shop">Smart litter boxes</a><a href="#shop">Accessories</a><a href="#shop">Find your setup</a></div><div><strong>THE DETAILS</strong><a href="#faq">FAQs</a><a href="#faq">Shipping & returns</a><a href="#faq">Contact</a></div><div><strong>FOLLOW THE PAWS</strong><a href="#top">Instagram ↗</a><a href="#top">TikTok ↗</a></div></div></div><div className="footer-bottom"><span>© 2026 SmartLitter. Made for cat people.</span><span>US & UK storefront concept · <a href="#top">Back to top ↑</a></span></div></footer>

    {cartOpen && <div className="cart-overlay" onMouseDown={e => { if (e.target === e.currentTarget) setCartOpen(false); }}><aside className="cart-drawer"><div className="cart-header"><div><div className="eyebrow">YOUR GOODIES</div><h2>Your bag <span>({count})</span></h2></div><button className="icon-button" onClick={() => setCartOpen(false)} aria-label="Close cart"><X/></button></div>{count === 0 ? <div className="empty-cart"><span>🐾</span><h3>It's a little empty in here.</h3><p>Your cat hasn't added anything. Yet.</p><button className="button button-dark" onClick={() => setCartOpen(false)}>Explore the shop <ArrowRight size={16}/></button></div> : <><div className="cart-items">{products.filter(p => cart[p.id]).map(p => <div className="cart-item" key={p.id}><div className="cart-thumb"><ProductArt shape={p.shape} color={p.color}/></div><div className="cart-item-info"><strong>{p.name}</strong><small>{p.subtitle}</small><b>{money(p.price)}</b><div className="quantity"><button onClick={() => change(p.id, -1)} aria-label="Decrease quantity"><Minus size={12}/></button><span>{cart[p.id]}</span><button onClick={() => change(p.id, 1)} aria-label="Increase quantity"><Plus size={12}/></button></div></div><button className="remove-item" onClick={() => change(p.id, -(cart[p.id] || 0))}>Remove</button></div>)}</div><div className="cart-summary"><div><span>Subtotal</span><strong>{money(total)}</strong></div><p>Shipping and taxes calculated at checkout.</p><button className="button button-dark checkout-button" onClick={() => alert('This is a storefront prototype. Connect Shopify checkout and configure payment processing before accepting real orders.')}>Continue to checkout <ArrowRight size={16}/></button><small><Check size={13}/> Secure checkout will be enabled before launch</small></div></>}</aside></div>}
  </main>;
}
